package com.bistro.launcher

import android.app.ActivityManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF0B100E)
private val Panel = Color(0xFF151E19)
private val Green = Color(0xFF57D995)
private val Muted = Color(0xFF9AAFA3)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val info = readDeviceInfo()
        setContent { BistroApp(info) }
    }

    @Suppress("DEPRECATION")
    private fun readDeviceInfo(): DeviceInfo {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val memory = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memory)
        val abis = Build.SUPPORTED_ABIS?.toList().orEmpty()
        val arch = when {
            abis.any { it == "arm64-v8a" } -> "ARM64"
            abis.any { it == "armeabi-v7a" } -> "ARM32"
            abis.any { it.contains("x86_64") } -> "x86_64"
            abis.any { it.contains("x86") } -> "x86"
            else -> "نامشخص"
        }
        return DeviceInfo(
            arch = arch,
            totalRamGb = memory.totalMem / (1024.0 * 1024 * 1024),
            lowRam = am.isLowRamDevice
        )
    }
}

data class DeviceInfo(val arch: String, val totalRamGb: Double, val lowRam: Boolean)

@Composable
fun BistroApp(device: DeviceInfo) {
    var page by remember { mutableStateOf("خانه") }
    var version by remember { mutableStateOf("1.20.1") }
    var message by remember { mutableStateOf("موتور اجرای بازی هنوز به پروژه متصل نشده است.") }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg, surface = Panel, primary = Green,
            onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Green) {
                    listOf("خانه", "نسخه‌ها", "تنظیمات").forEach { item ->
                        NavigationBarItem(
                            selected = page == item,
                            onClick = { page = item },
                            icon = {
                                Icon(
                                    when (item) {
                                        "خانه" -> Icons.Default.Home
                                        "نسخه‌ها" -> Icons.Default.ViewList
                                        else -> Icons.Default.Settings
                                    }, contentDescription = item
                                )
                            },
                            label = { Text(item) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Green,
                                selectedTextColor = Green,
                                indicatorColor = Color(0xFF263B30),
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("BISTRO", color = Green, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text("Launcher", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                    }
                    Surface(color = Panel, shape = RoundedCornerShape(50)) {
                        Text("JAVA EDITION", color = Muted, modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp), fontSize = 10.sp)
                    }
                }

                when (page) {
                    "خانه" -> {
                        Surface(color = Panel, shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                Text("آماده ماجراجویی؟", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                                Text("نسخه Minecraft Java موردنظرت را انتخاب کن.", color = Muted)
                                Text("نسخه انتخابی", color = Muted, fontSize = 12.sp)
                                VersionDropDown(version) { version = it }
                                Button(
                                    onClick = { message = "برای اجرای بازی، ابتدا باید موتور Java و رندرر به Bistro Launcher اضافه شوند." },
                                    modifier = Modifier.fillMaxWidth().height(54.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color(0xFF07110B)),
                                    shape = RoundedCornerShape(16.dp)
                                ) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                                    Spacer(Modifier.width(8.dp))
                                    Text("اجرای Minecraft", fontWeight = FontWeight.Bold)
                                }
                                Text(message, color = Muted, fontSize = 12.sp)
                            }
                        }
                        DeviceCard(device)
                        InfoCard("وضعیت پروژه", "رابط اولیه آماده است؛ دریافت نسخه، ورود حساب و موتور اجرای Java هنوز پیاده‌سازی نشده‌اند.")
                    }
                    "نسخه‌ها" -> {
                        Text("مدیریت نسخه‌ها", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        InfoCard("نسخه انتخابی", version)
                        listOf("1.8.9", "1.12.2", "1.16.5", "1.20.1", "1.21.1").forEach {
                            Surface(
                                color = if (version == it) Color(0xFF20392C) else Panel,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth().clickable { version = it }
                            ) {
                                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text("Minecraft Java $it", modifier = Modifier.weight(1f))
                                    if (version == it) Icon(Icons.Default.CheckCircle, null, tint = Green)
                                }
                            }
                        }
                        Text("این فهرست فعلاً انتخاب محلی نسخه است و هنوز چیزی دانلود نمی‌کند.", color = Muted, fontSize = 12.sp)
                    }
                    else -> {
                        Text("تنظیمات دستگاه", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        DeviceCard(device)
                        InfoCard("حافظه", "تنظیم RAM بازی پس از اتصال موتور اجرا اضافه می‌شود. مقدار امن باید بر اساس RAM آزاد دستگاه تعیین شود.")
                        InfoCard("گرافیک", "رندرر و تنظیمات گرافیکی پس از تشخیص GPU و اتصال موتور Java فعال می‌شوند.")
                    }
                }
                Text("Bistro Launcher • Prototype 0.1.0", color = Color(0xFF617269), fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
            }
        }
    }
}

@Composable
fun VersionDropDown(value: String, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        Surface(
            color = Color(0xFF202C25), shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().clickable { expanded = true }
        ) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Minecraft Java $value", modifier = Modifier.weight(1f))
                Icon(Icons.Default.ExpandMore, null, tint = Green)
            }
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            listOf("1.8.9", "1.12.2", "1.16.5", "1.20.1", "1.21.1").forEach {
                DropdownMenuItem(text = { Text(it) }, onClick = { onSelect(it); expanded = false })
            }
        }
    }
}

@Composable
fun DeviceCard(device: DeviceInfo) {
    Surface(color = Panel, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text("تشخیص خودکار دستگاه", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            DeviceRow("معماری پردازنده", device.arch)
            DeviceRow("RAM کل", String.format("%.1f GB", device.totalRamGb))
            DeviceRow("حالت حافظه کم", if (device.lowRam) "فعال" else "غیرفعال")
        }
    }
}

@Composable
fun DeviceRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Muted, fontSize = 13.sp)
        Text(value, color = Green, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun InfoCard(title: String, body: String) {
    Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(body, color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
        }
    }
}
