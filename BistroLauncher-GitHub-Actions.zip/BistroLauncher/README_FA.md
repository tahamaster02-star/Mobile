# Bistro Launcher — نسخه آغازین 0.1.0

این پروژه یک اسکلت اولیه Native Android با Kotlin و Jetpack Compose است.

## قابلیت‌های موجود
- رابط فارسی و تیره
- صفحه خانه، نسخه‌ها و تنظیمات
- انتخاب محلی نسخه Minecraft
- تشخیص خودکار ABI پردازنده از Android Build.SUPPORTED_ABIS
- خواندن RAM کل و وضعیت Low-RAM دستگاه

## مواردی که هنوز وجود ندارند
- دانلود فایل‌های رسمی Minecraft
- ورود Microsoft و بررسی مالکیت بازی
- دریافت Java Runtime
- موتور اجرای Minecraft و رندرر
- نصب‌کننده Fabric / Forge / NeoForge
- اجرای واقعی بازی

دکمه اجرای بازی عمداً اجرای جعلی انجام نمی‌دهد و وضعیت نبود موتور اجرا را اعلام می‌کند.

## ساخت APK
1. پروژه را در Android Studio باز کنید.
2. اجازه دهید Gradle Sync کامل شود.
3. از منوی Build گزینه Build APK(s) را انتخاب کنید.
4. خروجی debug معمولاً در مسیر زیر ساخته می‌شود:
   app/build/outputs/apk/debug/app-debug.apk

نیازمندی: Android Studio سازگار با Android Gradle Plugin 8.7.3 و JDK 17.

## نکته مهم درباره موتور اجرا
پیش از ادغام موتور، مجوزهای کد، وابستگی‌های بومی، رندررها و شرایط توزیع پروژه پایه باید جداگانه بررسی شوند. هیچ فایل Minecraft یا حساب کاربری در این پروژه قرار داده نشده است.


## ساخت APK با GitHub Actions از طریق موبایل

1. یک مخزن جدید در GitHub بسازید.
2. تمام محتویات پوشه BistroLauncher را در ریشه مخزن بارگذاری کنید؛ پوشه `.github/workflows` و فایل `android-build.yml` هم باید حفظ شوند.
3. پس از ثبت فایل‌ها، وارد زبانه Actions مخزن شوید.
4. اجرای `Build Bistro Launcher APK` را باز کنید. با push روی شاخه main/master نیز خودکار اجرا می‌شود.
5. پس از سبزشدن اجرای workflow، بخش Artifacts همان اجرای workflow را باز کنید و `BistroLauncher-debug-apk` را دانلود کنید.
6. ZIP خروجی را روی گوشی باز کنید؛ فایل `app-debug.apk` داخل آن است.

نکته: این workflow سورس را کامپایل می‌کند؛ تضمین نمی‌کند که موتور Minecraft وجود دارد. APK فعلی فقط نمونه اولیه رابط و تشخیص دستگاه است.
